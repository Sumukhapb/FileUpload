from django.apps import AppConfig


class DatetimeAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'datetime_app'
