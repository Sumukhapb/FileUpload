from django.shortcuts import render
from datetime import datetime, timedelta

def current_time(request):
    now = datetime.now()
    time_4_hours_ahead = now + timedelta(hours=4)
    time_4_hours_behind = now - timedelta(hours=4)

    return render(request, 'datetime_app/current_time.html', {
        'now': now,
        'time_4_hours_ahead': time_4_hours_ahead,
        'time_4_hours_behind': time_4_hours_behind,
    })
